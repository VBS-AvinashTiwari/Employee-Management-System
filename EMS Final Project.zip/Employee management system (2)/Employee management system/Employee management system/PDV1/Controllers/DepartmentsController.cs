﻿using Microsoft.AspNet.OData;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PDV1.DataAccess;
using PDV1.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PDV1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DepartmentsController : ControllerBase
    {
        private readonly IDataAccessProvide _dataAccessProvider;

        public DepartmentsController(IDataAccessProvide dataAccessProvider)
        {
            _dataAccessProvider = dataAccessProvider;
        }

        [HttpGet]
        //[Authorize(Policy ="PublicSecure")]
        [EnableQuery()]
        public async Task<IActionResult> Get()
        {
            try
            {
                var result = await _dataAccessProvider.GetDeps();
                if (result == null)
                {
                    return NotFound();
                }
                return Ok(result);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Department department)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    Guid obj = Guid.NewGuid();
                    department.id = obj.ToString();
                    var result = await _dataAccessProvider.AddDep(department);
                    if (result != null)
                    {
                        return Created("Object Created", department);
                    }
                    return NotFound();
                }
                catch (Exception)
                {
                    return BadRequest();
                }
            }
            return BadRequest();
        }

        [HttpGet("{id}")]
        // [Authorize(Policy = "PublicSecure")]
        [EnableQuery()]
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            try
            {
                var result = await _dataAccessProvider.GetDep(id);
                if (result == null)
                {
                    return NotFound();
                }
                return Ok(result);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        [HttpPut]
        public async Task<IActionResult> Edit([FromBody] Department department)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var result = await _dataAccessProvider.UpdateDep(department);
                    return Ok(result);
                }
                catch (Exception ex)
                {
                    if (ex.GetType().FullName == "Microsoft.EntityFrameworkCore.DbUpdateConcurrencyException")
                    {
                        return NotFound();
                    }
                    return BadRequest();
                }
            }
            return BadRequest();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            try
            {
                var data = await _dataAccessProvider.GetDep(id);
                if (data == null)
                {
                    return NotFound();
                }
                var result = _dataAccessProvider.DeleteDep(id);
                if (result.Equals("Department doesn't exist"))
                {
                    return NotFound();
                }
                return Ok();
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
    }
}
