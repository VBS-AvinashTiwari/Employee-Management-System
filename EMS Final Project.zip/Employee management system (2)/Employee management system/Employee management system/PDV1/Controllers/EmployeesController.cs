﻿using Microsoft.AspNet.OData;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PDV1.DataAccess;
using PDV1.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PDV1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {
        private readonly IEmployee _employeerepo;

        public EmployeesController(IEmployee employeeRepo)
        {
            _employeerepo = employeeRepo;
        }

        [HttpGet]
        //[Authorize(Policy = "PublicSecure")]
        [EnableQuery()]
        public async Task<IActionResult> Get()
        {
            try
            {
                var result = await _employeerepo.GetEmps();
                if (result == null)
                {
                    return NotFound();
                }
                return Ok(result);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        [HttpPost]
        //[Authorize(Policy = "PublicSecure")]
        public async Task<IActionResult> Create([FromBody] Employee employee)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    Guid obj = Guid.NewGuid();
                    employee.id = obj.ToString();
                    var result = await _employeerepo.AddEmp(employee);
                    if (result != null)
                    {
                        return Created("Object Created", employee);
                    }
                    return NotFound();
                }
                catch (Exception)
                {
                    return BadRequest();
                }
            }
            return BadRequest();
        }

        [HttpGet("{id}")]
        //[Authorize(Policy = "PublicSecure")]
        [EnableQuery()]
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            try
            {
                var result = await _employeerepo.GetEmp(id);
                if (result == null)
                {
                    return NotFound();
                }
                return Ok(result);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
        [HttpPut]
        public async Task<IActionResult> Edit([FromBody] Employee employee)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var result = await _employeerepo.UpdateEmp(employee);
                    return Ok(result);
                }
                catch (Exception ex)
                {
                    if (ex.GetType().FullName == "Microsoft.EntityFrameworkCore.DbUpdateConcurrencyException")
                    {
                        return NotFound();
                    }
                    return BadRequest();
                }
            }
            return BadRequest();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            try
            {
                var data = await _employeerepo.GetEmp(id);
                if (data == null)
                {
                    return NotFound();
                }
                var result = _employeerepo.DeleteEmp(id);
                if (result.Equals("Employee doesn't exist"))
                {
                    return NotFound();
                }
                return Ok();
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
    }
}
