﻿using Microsoft.EntityFrameworkCore;
using PDV1.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PDV1.DataAccess
{
    public class DataAccessProvider : IDataAccessProvide
    {
        private readonly PostgreSqlContext _context;

        public DataAccessProvider(PostgreSqlContext context)
        {
            _context = context;
        }
        public async Task<string> AddDep(Department department)
        {
            if (_context != null)
            {
                await _context.departments.AddAsync(department);
                await _context.SaveChangesAsync();
                return ("Department added to Database");
            }
            return null;
        }
        public async Task<string> DeleteDep(string id)
        {
            if (_context != null)
            {
                var entity = await _context.departments.FindAsync(id);
                if (entity != null)
                {
                    _context.departments.Remove(entity);
                    await _context.SaveChangesAsync();
                    return ("Department Deleted From Database");
                }
                return ("Department doesn't exist");
            }
            return null;
        }
        public async Task<Department> GetDep(string id)
        {
            if (_context != null)
            {
                return await _context.departments.FindAsync(id);
            }
            return null;
        }

        public async Task<List<Department>> GetDeps()
        {
            return await _context.departments.ToListAsync();
        }

        public async Task<string> UpdateDep(Department department)
        {
            if (_context != null)
            {
                _context.departments.Update(department);
                await _context.SaveChangesAsync();
                return ("Department Updated");
            }
            return null;
        }

       
    }
}
