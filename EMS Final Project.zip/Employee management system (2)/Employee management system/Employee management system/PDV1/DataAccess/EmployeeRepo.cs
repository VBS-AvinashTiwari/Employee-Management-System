﻿using Microsoft.EntityFrameworkCore;
using PDV1.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PDV1.DataAccess
{
    public class EmployeeRepo : IEmployee
    {
        private readonly PostgreSqlContext _context;

        public EmployeeRepo(PostgreSqlContext context)
        {
            _context = context;
        }
        public async Task<string> AddEmp(Employee employee)
        {
            if(_context!= null)
            {
                await _context.employees.AddAsync(employee);
                await _context.SaveChangesAsync();
                return ("Employee added to Database");
            }

            return null;           
        }

        public async Task<string>  DeleteEmp(string id)
        {
            if (_context != null)
            {
                var entity = await _context.employees.FindAsync(id);
                if (entity != null)
                {
                    _context.employees.Remove(entity);
                    await _context.SaveChangesAsync();
                    return ("Employee Deleted From Database");
                }
                return ("Employee doesn't exist");
            }
            return null;
        }

        public async Task<Employee>  GetEmp(string id)
        {
            if (_context != null)
            {
                return await _context.employees.FindAsync(id);
            }
            return null;
        }

        public async Task<List<Employee>> GetEmps()
        { 
            return await _context.employees.ToListAsync();
        }

        public async Task<string> UpdateEmp(Employee employee)
        {
            if (_context != null)
            {
                _context.employees.Update(employee);
                await _context.SaveChangesAsync();
                return ("Employee Updated");
            }
            return null;
        }
       
    }
}
