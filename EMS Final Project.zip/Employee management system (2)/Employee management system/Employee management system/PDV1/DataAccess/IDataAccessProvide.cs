﻿using PDV1.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PDV1.DataAccess
{
    public interface IDataAccessProvide
    {
        
        Task<string> AddDep (Department department);
        Task<string> UpdateDep(Department department);
        Task<string> DeleteDep(string id);
        Task<Department> GetDep(string id);
        Task<List<Department>> GetDeps();
       
    }
}
