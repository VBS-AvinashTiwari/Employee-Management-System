﻿using PDV1.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PDV1.DataAccess
{
    public interface IEmployee
    {
        Task<string> AddEmp(Employee employee);
        Task<string> UpdateEmp(Employee employee);
        Task<string> DeleteEmp(string id);
        Task<Employee> GetEmp(string id);
        Task<List<Employee>> GetEmps();

    }
}
