const variables={
    API_URL:"https://localhost:44355/api/"
}