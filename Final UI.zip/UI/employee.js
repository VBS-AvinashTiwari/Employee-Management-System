const employee={template:`
<div>
<button type="button"
class="btn btn-primary m-2 fload-end"
data-bs-toggle="modal"
data-bs-target="#exampleModal"
@click="addClick()">
 Add Employee
</button>
<table class="table table-striped">
<thead>
    <tr>
        <th>
            Employee Id
        </th>
        <th>
        
            <div class="d-flex flex-row">
            <input class="form-control m-2"
                v-model="EmployeeNameFilter"
                v-on:keyup="FilterFn()"
                placeholder="Filter">
                
                <button type="button" class="btn btn-light"
                @click="sortResult('name',true)">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-down-square-fill" viewBox="0 0 16 16">
                <path d="M2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2zm6.5 4.5v5.793l2.146-2.147a.5.5 0 0 1 .708.708l-3 3a.5.5 0 0 1-.708 0l-3-3a.5.5 0 1 1 .708-.708L7.5 10.293V4.5a.5.5 0 0 1 1 0z"/>
                </svg>
                </button>
                <button type="button" class="btn btn-light"
                @click="sortResult('name',false)">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-up-square-fill" viewBox="0 0 16 16">
                <path d="M2 16a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H2zm6.5-4.5V5.707l2.146 2.147a.5.5 0 0 0 .708-.708l-3-3a.5.5 0 0 0-.708 0l-3 3a.5.5 0 1 0 .708.708L7.5 5.707V11.5a.5.5 0 0 0 1 0z"/>
                </svg>
                </button>
            </div>
            Employee Name
        </th>
        <th>
        <div class="d-flex flex-row">
        <input class="form-control m-2"
            v-model="EmployeeDepartmentFilter"
            v-on:keyup="FilterFn()"
            placeholder="Filter">
            
            <button type="button" class="btn btn-light"
            @click="sortResult('depname',true)">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-down-square-fill" viewBox="0 0 16 16">
            <path d="M2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2zm6.5 4.5v5.793l2.146-2.147a.5.5 0 0 1 .708.708l-3 3a.5.5 0 0 1-.708 0l-3-3a.5.5 0 1 1 .708-.708L7.5 10.293V4.5a.5.5 0 0 1 1 0z"/>
            </svg>
            </button>
            <button type="button" class="btn btn-light"
            @click="sortResult('depname',false)">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-up-square-fill" viewBox="0 0 16 16">
            <path d="M2 16a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H2zm6.5-4.5V5.707l2.146 2.147a.5.5 0 0 0 .708-.708l-3-3a.5.5 0 0 0-.708 0l-3 3a.5.5 0 1 0 .708.708L7.5 5.707V11.5a.5.5 0 0 0 1 0z"/>
            </svg>
            </button>
        </div>
            Department Name
        </th>
        <th>
            Salary
        </th>
        <th>
            Gender
        </th>
    </tr>
</thead>
<tbody>
    <tr v-for="emp in employees" :key="id">
        <td>{{emp.id}}</td>
        <td>{{emp.name}}</td>
        <td>{{emp.depname}}</td>
        <td>{{emp.salary}}</td>
        <td>{{emp.gender}}</td>

        <td>
            <button type="button"
            class="btn btn-light mr-1"
            data-bs-toggle="modal"
            data-bs-target="#exampleModal"
            @click="editClick(emp)">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
                </svg>
            </button>
            <button type="button" @click="deleteClick(emp.id)"
            class="btn btn-light mr-1">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash-fill" viewBox="0 0 16 16">
                <path d="M2.5 1a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1H3v9a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V4h.5a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1H2.5zm3 4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 .5-.5zM8 5a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7A.5.5 0 0 1 8 5zm3 .5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 1 0z"/>
                </svg>
            </button>
        </td>
    </tr>
</tbody>
</table>
<div class="modal fade" id="exampleModal" tabindex="-1"
    aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog modal-lg modal-dialog-centered">
<div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">{{modalTitle}}</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"
        aria-label="Close"></button>
    </div>
    <div class="modal-body">
    <div class="d-flex flex-row bd-highlight mb-3">
        <div class="p-2 w-50 bd-highlight">
            <div class="input-group mb-3">
                <span class="input-group-text">Employee Name</span>
                <input type="text" class="form-control" v-model="name">
            </div>
            <div class="input-group mb-3">
                <span class="input-group-text">Department Name</span>
                <select class="form-select" v-model="depname">
                    <option v-for="dep in departments" :key="dep.id">
                    {{dep.name}}
                    </option>
                </select>
            </div>
            <div class="input-group mb-3">
                <span class="input-group-text">Salary</span>
                <input type="number" class="form-control" v-model="salary">
            </div>
            <div class="input-group mb-3">
            <span class="input-group-text">Gender</span>
                <select class="form-select" v-model="gender">
                    <option v-for="(gen,i) in genderDropdown" :key=i>
                        {{gen}}
                    </option>
                </select>

        </div>
        </div>
    </div>
        <button type="button" @click="createClick()"
        v-if="id==''" class="btn btn-primary">
        Create
        </button>
        <button type="button" @click="updateClick()"
        v-if="id!=''" class="btn btn-primary">
        Update
        </button>
    </div>
</div>
</div>
</div>
</div>
`,

data(){
    return{
        genderDropdown: ['Male','Female','Others'],
        departments:[],
        employees:[],
        modalTitle:"",
        id:'',
        name:"",
        depname:"",
        salary:0,
        gender:'',
        EemployeeNameFilter:"",
        EmployeeDepartmentFilter:"",
        employeesWithoutFilter:[]
    }
},
methods:{
    refreshData(){
        axios.get(variables.API_URL+"employees")
        .then((response)=>{
            this.employees=response.data.value;
            this.employeesWithoutFilter=response.data.value;
        });

        axios.get(variables.API_URL+"departments")
        .then((response)=>{
            this.departments=response.data.value;
           
        });
    },
    addClick(){
        this.modalTitle="Add Employee";
        this.id="";
        this.name="";
        this.depname="";
        this.salary=0;
        this.gender="";
    },
    editClick(emp){
        this.modalTitle="Edit Employee";
        this.id=emp.id;
        this.name=emp.name;
        this.depname=emp.depname;
        this.salary=emp.salary;
        this.gender=emp.gender;
    },
    createClick(){
        axios.post(variables.API_URL+"employees",{
            name:this.name,
            depname:this.depname,
            salary:this.salary,
            gender:this.gender

        })
        .then((response)=>{
            this.refreshData();
            alert("Added Successfully");
        });
    },
    updateClick(){
        axios.put(variables.API_URL+"employees",{
            id:this.id,
            name:this.name,
            depname:this.depname,
            salary:this.salary,
            gender:this.gender
        })
        .then((response)=>{
            this.refreshData();
            alert("Updated Successfully");
        });
    },
    deleteClick(id){
        if(!confirm("Are you sure?")){
            return;
        }
        axios.delete(variables.API_URL+"employees/"+id)
        .then((response)=>{
            this.refreshData();
            alert("Deleted Successfully");
        });

    },
    FilterFn(){
        var EmployeeNameFilter=this.EmployeeNameFilter;
        var EmployeeDepartmentFilter=this.EmployeeDepartmentFilter;

        this.employees=this.employeesWithoutFilter.filter(
            function(el){
                return el.name.toString().toLowerCase().includes(
                    EmployeeNameFilter.toString().trim().toLowerCase()
                )&&
                el.depname.toString().toLowerCase().includes(
                    EmployeeDepartmentFilter.toString().trim().toLowerCase()
                )
            });
    },
    sortResult(prop,asc){
        this.employees=this.employeesWithoutFilter.sort(function(a,b){
            if(asc){
                return (a[prop]>b[prop])?1:((a[prop]<b[prop])?-1:0);
            }
            else{
                return (b[prop]>a[prop])?1:((b[prop]<a[prop])?-1:0);
            }
        })
    }

   

},
mounted:function(){
    this.refreshData();
}

}